import rateLimit from 'express-rate-limit';
export const apiRateLimit=rateLimit({windowMs:Number(process.env.RATE_LIMIT_WINDOW_MS||60000),limit:Number(process.env.RATE_LIMIT_MAX||60),standardHeaders:'draft-8',legacyHeaders:false,message:{error:'Rate limit exceeded. Please retry later.'}});
