import path from 'node:path';
export const config={
 port:Number(process.env.PORT||8787),
 dbPath:path.resolve(process.env.DATABASE_PATH||'./data/mediaforge.db'),
 frontendOrigin:process.env.FRONTEND_ORIGIN||'http://localhost:8787',
 requestTimeoutMs:Number(process.env.REQUEST_TIMEOUT_MS||20000),
 maxRedirects:Number(process.env.MAX_REDIRECTS||5),
 maxAnalyzeBytes:Number(process.env.MAX_ANALYZE_BYTES||2097152),
 maxHtmlBytes:Number(process.env.MAX_HTML_BYTES||5242880),
 maxDownloadBytes:Number(process.env.MAX_DOWNLOAD_BYTES||5368709120),
 ffmpegBin:process.env.FFMPEG_BIN||'ffmpeg',
 allowPrivateTest:process.env.MEDIAFORGE_ALLOW_PRIVATE_TEST==='1'
};
