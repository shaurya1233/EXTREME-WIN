import {readFile} from 'node:fs/promises';
const files=['backend/server.js','backend/app.js','backend/services/analyzer.js','backend/services/downloader.js','frontend/app.ts'];
for (const file of files) {
  const text=await readFile(file,'utf8');
  if (/TODO|FIXME|fakeDownload|simulateProgress|mockResponse/.test(text)) throw new Error(`Forbidden placeholder token in ${file}`);
}
console.log('Static placeholder/security lint passed.');
