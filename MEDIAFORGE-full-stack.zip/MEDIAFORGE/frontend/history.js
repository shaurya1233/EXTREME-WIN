export {getHistory,addHistory,clearHistoryLocal} from './storage.js';
