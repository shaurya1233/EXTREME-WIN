export async function api(path:string, options:RequestInit={}){const headers=new Headers(options.headers);if(options.body)headers.set('content-type','application/json');const r=await fetch(path,{...options,headers});let body:any=null;try{body=await r.json()}catch{}if(!r.ok)throw new Error(body?.error||body?.reason||`HTTP ${r.status}`);return body}
export async function health():Promise<any>{return api('/api/health')}
export async function capabilities():Promise<any>{return api('/api/capabilities')}
export async function analyze(url:string):Promise<any>{return api('/api/analyze',{method:'POST',body:JSON.stringify({url})})}
export async function startDownload(data:Record<string,unknown>):Promise<any>{return api('/api/download',{method:'POST',body:JSON.stringify(data)})}
export async function status(id:string):Promise<any>{return api(`/api/status/${encodeURIComponent(id)}`)}
export async function cancel(id:string):Promise<any>{return api(`/api/cancel/${encodeURIComponent(id)}`,{method:'POST'})}
