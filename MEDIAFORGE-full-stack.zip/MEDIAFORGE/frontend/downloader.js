export function supportsFileSystemAccess(){return 'showSaveFilePicker' in window;}
