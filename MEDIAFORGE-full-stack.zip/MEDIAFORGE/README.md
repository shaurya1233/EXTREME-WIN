# MEDIAFORGE

MEDIAFORGE is a production-oriented, authorized public-media analyzer/downloader. It separates the static browser application from the server capabilities that require Node.js, Express, network access, native FFmpeg, and SQL storage.

## Architecture

- **GitHub Pages:** `frontend/` static HTML/CSS/compiled JavaScript and optional browser WebAssembly.
- **Backend:** Node.js + Express REST API. Performs SSRF-protected URL analysis and real streaming downloads.
- **SQL:** SQLite via `better-sqlite3` for media metadata, jobs, and server history.
- **Browser storage:** IndexedDB for local history.
- **FFmpeg:** optional native server capability for future/authorized processing. The current safe production download path does not invoke it unnecessarily.
- **CI/CD:** GitHub Actions runs tests/build and deploys only the static frontend to GitHub Pages.

## Why this is not a universal downloader

A URL can resolve to HTML, direct media, HLS/DASH, authentication, DRM, a private resource, or an unsupported response. MEDIAFORGE reports the detected condition and does not bypass access controls, DRM, CAPTCHA, paywalls, private resources, or authentication.

## Project structure

```text
frontend/              static UI and browser modules
backend/               Express API, analyzer, downloader, security, DB
 database/schema.sql   SQLite schema
tests/                 automated unit/integration tests
scripts/               build/lint helpers
.github/workflows/     test + GitHub Pages deployment
Dockerfile             backend container
docker-compose.yml     local backend container
```

## Local setup

Requirements: Node.js 20+ and npm.

```bash
npm ci
cp .env.example .env
npm run check
npm start
```

Open `http://localhost:8787`. The backend serves the API; the GitHub Pages build is generated with `npm run build`.

For local fixture testing, the automated tests use `MEDIAFORGE_ALLOW_PRIVATE_TEST=1` so they can target loopback fixture servers. **Never enable that flag in production.**

## Environment

See `.env.example` for:

- `PORT`
- `FRONTEND_ORIGIN`
- `DATABASE_PATH`
- request/response limits
- rate limits
- `FFMPEG_BIN`
- `MEDIAFORGE_ALLOW_PRIVATE_TEST`

## API

### `GET /api/health`

Reports backend availability and actual capabilities, including whether FFmpeg is installed.

### `GET /api/capabilities`

Reports supported formats and analysis classes.

### `POST /api/analyze`

```json
{"url":"https://example.com/media"}
```

The analyzer validates the URL, follows a bounded redirect chain, inspects status/content type/size/range support, discovers public HTML media metadata, and detects HLS/DASH manifests.

### `POST /api/download`

```json
{"url":"https://example.com/video.mp4","mediaUrl":"https://example.com/video.mp4","requestedFormat":"mp4","title":"Example"}
```

Only a confirmed MP4/WebM direct resource should be submitted. The server streams bytes to a temporary file without loading the whole media file into RAM.

### `GET /api/status/:jobId`

Returns real job state and byte counters.

### `POST /api/cancel/:jobId`

Cancels an active backend stream.

### `GET /api/history` / `DELETE /api/history`

Server-side SQL history.

## Security

The backend treats every URL as untrusted input. It validates HTTP(S), blocks localhost/private/link-local/multicast targets by default, revalidates every redirect, applies timeouts and response limits, uses rate limiting and Helmet, and never constructs a shell command from user input.

For additional production hardening, deploy the backend behind TLS, authentication appropriate to your users, a reverse proxy, observability, egress filtering and a dedicated worker/storage policy.

## FFmpeg

FFmpeg is detected by `/api/health`. Native FFmpeg is deliberately not required for a direct MP4/WebM copy download. If a future processing provider needs FFmpeg, invoke it with an argument array rather than a shell string and enforce the same source authorization/security rules.

## GitHub Pages deployment

GitHub Pages runs only the static frontend. It does **not** run Node.js, Express, SQL, persistent REST endpoints, or native server FFmpeg.

The `deploy.yml` workflow builds TypeScript and publishes `dist/` to GitHub Pages. Host the backend separately and set the frontend API base to the backend origin when cross-origin deployment is used. The sample frontend is intentionally same-origin for the simplest secure deployment; adapt `api.js` to a known HTTPS backend origin for a split deployment.

## Testing

```bash
MEDIAFORGE_ALLOW_PRIVATE_TEST=1 npm test
npm run build
```

The integration suite uses local fixture servers and verifies real byte transfer, not simulated progress. The frontend test checks that the production code does not contain fake download/progress markers.

## Known supported cases

- Direct HTTP(S) MP4/WebM with actual content type or extension.
- Public HTML pages exposing direct media through standard `<video>`, `<audio>`, `<source>`, Open Graph video, or Twitter player stream metadata, subject to server accessibility.
- HLS/DASH manifest detection and metadata parsing. Segment assembly is intentionally not claimed by the current direct-download provider.
- Real HTTP redirects within the configured limit.

## Known unsupported / constrained cases

- DRM-protected media.
- Authenticated/private media.
- CAPTCHA or paywall-gated resources.
- Anti-download/access-control bypass.
- Browser-only CORS-restricted analysis when no backend is available.
- HLS/DASH segment assembly in the current safe direct-download provider.
- Arbitrary website-specific extraction logic not implemented as a provider.

## Technology matrix

| Technology | Stored in GitHub | Executes on GitHub Pages | Role |
|---|---:|---:|---|
| HTML/CSS/JS | Yes | Yes | Static UI |
| TypeScript | Yes | After compilation | Type-safe frontend source |
| Node/Express | Yes | No | Backend API |
| REST/JSON | Yes | Browser + backend | API transport |
| SQL | Yes | No SQL server on Pages | Server persistence |
| FFmpeg | Yes/configured separately | Native server; WASM possible | Authorized media processing |
| WebAssembly | Yes | Yes when loaded | Browser-side compute where appropriate |
| GitHub Actions | Yes | CI/CD | Test/build/deploy |
